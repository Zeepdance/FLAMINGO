#include "esp_camera.h"
#include <WiFi.h>
#include <WebServer.h>

#define CAMERA_MODEL_ESP32S3_EYE   // или ваша плата
#include "camera_pins.h"

#define RELAY_GPIO  21

const char* ssid = "ESP32_CAM";
const char* password = "12345678";

WebServer server(80);
camera_config_t camera_config;

void handleCapture() {
  Serial.println("Capture requested");
  digitalWrite(RELAY_GPIO, LOW);   // Включаем ИК (LOW)
  delay(200);                      // Ждём стабилизации ИК и экспозиции

  camera_fb_t *fb = esp_camera_fb_get();
  if (!fb) {
    Serial.println("Capture failed");
    digitalWrite(RELAY_GPIO, HIGH);
    server.send(500, "text/plain", "Capture failed");
    return;
  }
  Serial.printf("Captured: %d bytes\n", fb->len);

  WiFiClient client = server.client();
  String header = "HTTP/1.1 200 OK\r\n"
                  "Content-Type: image/jpeg\r\n"
                  "Content-Length: " + String(fb->len) + "\r\n"
                  "Connection: close\r\n\r\n";
  client.write(header.c_str(), header.length());
  client.write(fb->buf, fb->len);
  client.stop();

  esp_camera_fb_return(fb);

  delay(50);                       // Небольшая пауза перед выключением
  digitalWrite(RELAY_GPIO, HIGH);  // Выключаем ИК
  Serial.println("Capture complete");
}

void setup() {
  Serial.begin(115200);
  pinMode(RELAY_GPIO, OUTPUT);
  digitalWrite(RELAY_GPIO, HIGH);

  // --- Конфигурация камеры: VGA, высокое качество ---
  camera_config.ledc_channel = LEDC_CHANNEL_0;
  camera_config.ledc_timer = LEDC_TIMER_0;
  camera_config.pin_d0 = Y2_GPIO_NUM;
  camera_config.pin_d1 = Y3_GPIO_NUM;
  camera_config.pin_d2 = Y4_GPIO_NUM;
  camera_config.pin_d3 = Y5_GPIO_NUM;
  camera_config.pin_d4 = Y6_GPIO_NUM;
  camera_config.pin_d5 = Y7_GPIO_NUM;
  camera_config.pin_d6 = Y8_GPIO_NUM;
  camera_config.pin_d7 = Y9_GPIO_NUM;
  camera_config.pin_xclk = XCLK_GPIO_NUM;
  camera_config.pin_pclk = PCLK_GPIO_NUM;
  camera_config.pin_vsync = VSYNC_GPIO_NUM;
  camera_config.pin_href = HREF_GPIO_NUM;
  camera_config.pin_sccb_sda = SIOD_GPIO_NUM;
  camera_config.pin_sccb_scl = SIOC_GPIO_NUM;
  camera_config.pin_pwdn = PWDN_GPIO_NUM;
  camera_config.pin_reset = RESET_GPIO_NUM;
  camera_config.xclk_freq_hz = 20000000;
  camera_config.pixel_format = PIXFORMAT_JPEG;
  camera_config.frame_size = FRAMESIZE_VGA;
  camera_config.jpeg_quality = 12;
  camera_config.fb_count = 1;

  if (psramFound()) {
    camera_config.fb_location = CAMERA_FB_IN_PSRAM;
    camera_config.fb_count = 2;
    camera_config.grab_mode = CAMERA_GRAB_LATEST;
  } else {
    camera_config.fb_location = CAMERA_FB_IN_DRAM;
  }

  esp_err_t err = esp_camera_init(&camera_config);
  if (err != ESP_OK) {
    Serial.printf("Camera init failed: 0x%x", err);
    return;
  }
  Serial.println("Camera initialized (VGA, quality 12)");

  WiFi.softAP(ssid, password);
  WiFi.setSleep(true);
  WiFi.setTxPower(WIFI_POWER_8_5dBm);
  Serial.print("AP IP: ");
  Serial.println(WiFi.softAPIP());

  server.on("/capture", handleCapture);
  server.begin();
  Serial.println("HTTP server started");
}

void loop() {
  server.handleClient();
}